#!/bin/bash
# backup_full.sh <origen> [destino]   (destino por defecto: /backup_dir)

if [ -z "$1" ] || [ "$1" = "-help" ] || [ "$1" = "--help" ]; then
    echo "Uso: $0 <origen> [destino]"
    echo "  origen   directorio a backupear (ej: /var/log)"
    echo "  destino  filesystem montado donde se guarda (por defecto: /backup_dir)"
    echo "Genera <nombre>_bkp_YYYYMMDD.tar.gz en el destino"
    exit 0
fi

ORIGEN="${1%/}"
DESTINO="${2:-/backup_dir}"
DESTINO="${DESTINO%/}"

[ -d "$ORIGEN" ] || { echo "Error: origen '$ORIGEN' no disponible" >&2; exit 2; }
mountpoint -q "$DESTINO" || { echo "Error: destino '$DESTINO' no está montado" >&2; exit 3; }

NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_$(date +%Y%m%d).tar.gz"
TEMP=$(mktemp -d "$DESTINO/.tmp.XXXXXX")

cp -a "$ORIGEN" "$TEMP/" && tar -czf "$ARCHIVO" -C "$TEMP" "$NOMBRE" \
    && echo "Backup OK: $ARCHIVO" || echo "Error en el backup" >&2
rm -rf "$TEMP"
