history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
apt upgrade
vi /etc/apt/sources.list
clear
apt update
apt upgrade -y
dpkg --configure a
dpkg --configure -a
clear
apt -f install
apt full-upgrade -y
reboot
cat /etc/debian_version
dpkg --configure -a
apt -f install
apt upgrade -y
apt full-upgrade -y
reboot
cat /etc/debian_version
vim /etc/apt/sources.list
apt-update
apt update
vim /etc/apt/sources.list'



clear
vim /etc/apt/sources.list
apt update
clear
vim /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs -y
apt full-upgrade -y
reboot
exit
hostnamectl set-hostname TPServer
clear
hostname
sed -i 's/127\.0\.1\.1.*/127.0.1.1\tTPServer/' /etc/hosts
mkdir -p /root/.ssh && chmod 700 /root/.ssh
ssh-keygen -t rsa -b 4096 -f /root/.ssh/id_rsa -N ""
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/^#\?PubkeyAuthentication.*/PubkeyAuthentication yes/' /etc/ssh/sshd_config
systemctl enable --now ssh && systemctl restart ssh
exit
clear
exit
clear
scp root@192.168.1.76:/root/.ssh/id_rsa .
ssh -i id_rsa root@192.168.1.76
exit
sed -i 's/^PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
systemctl restart ssh
apt update
apt install -y apache2 php libapache2-mod-php php-mysql
php -v
cp /root/index.php /root/logo.png /var/www/html/
ls -la /root
tar tzf /root/Material_Adicional_TPVMCA.tar.gz
mv /root/Material_Adicional_TPVMCA/* /root/
cd /root
clear
ls
tar xzf Material_Adicional_TPVMCA.tar.gz
ls -la /root/Material_Adicional_TPVMCA
mv /root/Material_Adicional_TPVMCA/* /root/
rmdir /root/Material_Adicional_TPVMCA
ls /root
cp /root/index.php /root/logo.png /var/www/html/
rm -f /var/www/html/index.html
systemctl enable --now apache2
apt install -y mariadb-server
systemctl enable --now mariadb
mariadb < /root/db.sql
mariadb -e "SHOW DATABASES;"
clear
rm -f /root/id_rsa /root/id_rsa.pub
rm -f /root/.ssh/id_rsa /root/.ssh/id_rsa.pub
rm -f /root/.ssh/id_rsa /root/.ssh/id_rsa.pub
> /root/.ssh/authorized_keys
ls -la /root /root/.ssh
mkdir -p /root/.ssh && chmod 700 /root/.ssh
clear
cat /root/clave_publica.pub > /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
chmod 600 /root/clave_privada.txt
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/^#\?PubkeyAuthentication.*/PubkeyAuthentication yes/' /etc/ssh/sshd_config
systemctl restart ssh
clear
exit
clear
ls
exit
clear
exit
clear
chmod 600 /root/clave_privada.txt
ssh -i /root/clave_privada.txt -o PasswordAuthentication=no -o StrictHostKeyChecking=no
clear
ssh -i /root/clave_privada.txt -o PasswordAuthentication=no -o StrictHostKeyChecking=no root@localhost "echo OK"
clear
sed -i 's/^PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
systemctl restart ssh
sed -i 's/^PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
systemctl restart ssh
apt update
apt install -y apache2 php libapache2-mod-php php-mysql
systemctl status apache2 mariadb --no-pager | grep -E "●|Active"
clear
cp /root/index.php /root/logo.png /var/www/html/
rm -f /var/www/html/index.html
mariadb -e "SHOW DATABASES;"
clear
ip a
ip route
cp /etc/network/interfaces /etc/network/interfaces.bak
vi /etc/network/interfaces
clear
systemctl restart networking
ip a
ip route
ping 8.8.8.8
clear
ls
exit
history
systemctl status ssh
systemctl enable --now ssh
clear
ls
systemctl restart ssh
sed -i 's/^PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sed -i 's/^PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
systemctl restart ssh
